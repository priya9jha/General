package com.interfaces;

public interface Slab_D {
    default double  slab(int sal){
        double tax=0;
        tax=sal*0.25;
        return tax;

    }
}
