package com.interfaces;

public interface Slab_B {
    default double  slab(int sal){
        double tax = 0;

            tax=sal*0.025;
        return tax;

    }
}
