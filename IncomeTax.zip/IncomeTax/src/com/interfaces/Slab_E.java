package com.interfaces;

public interface Slab_E {
    default double  slab(int sal){
        double tax=sal*0.3;
        return tax;

    }
}
