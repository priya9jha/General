package com.calculation;

import com.interfaces.*;

public class Calculate_Tax implements Slab_A, Slab_B, Slab_C, Slab_D, Slab_E {

    double tax=0;



    @Override
    public double slab(int sal) {

        if(sal<=400000)
            tax+=Slab_A.super.slab(sal);
        else
            if(sal>400000){

                tax=tax+Slab_A.super.slab(150000)+Slab_B.super.slab(150000);

                System.out.println("Tax for slab A="+Slab_A.super.slab(150000));
                System.out.println("Tax for slab B="+Slab_B.super.slab(150000));
                sal=sal-300000;
                System.out.println("Salary remaining for Tax before C="+sal);
                if(sal<=500000)
                {
                    tax+=Slab_C.super.slab(sal);
                    System.out.println("Tax for slab C="+Slab_C.super.slab(sal));
                    return tax;
                }
                else
                {
                    tax+=Slab_C.super.slab(500000);
                    System.out.println("Tax for slab C="+Slab_C.super.slab(500000));
                }

                sal=sal-500000;
                System.out.println("Salary remaining for Tax before D="+sal);
                if(sal<=9200000)
                {
                    tax+=Slab_D.super.slab(sal);
                    System.out.println("Tax for slab D="+Slab_D.super.slab(sal));
                    return tax;
                }
                else
                {
                    tax+=Slab_D.super.slab(9200000);
                    System.out.println("Tax for slab D="+Slab_D.super.slab(9200000));
                }
                System.out.println("Salary remaining for Tax before E="+sal);
                sal=sal-9200000;

                tax+=Slab_E.super.slab(sal);
                System.out.println("Tax for slab E="+Slab_E.super.slab(sal));

                System.out.println("Salary remaining for Tax after E="+sal);

            }


        return tax;
    }
}
