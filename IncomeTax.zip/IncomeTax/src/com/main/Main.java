package com.main;

import com.calculation.Calculate_Gross;
import com.calculation.Calculate_Tax;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int salary = 500000;
        int net=400001;
        Calculate_Tax c=new Calculate_Tax();
        double tax=c.slab(salary);
        System.out.println("Tax calculated for salary="+salary+" is="+tax);

        Calculate_Gross cg=new Calculate_Gross();
        double gross=cg.gross(net);
        System.out.println("Gross income for net income="+net+" is="+gross);

    }
}
