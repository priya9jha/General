package com.interfaces;

public interface Slab_C {
    default double  slab(int sal){

        double tax=sal*0.1;
        return tax;

    }
}
