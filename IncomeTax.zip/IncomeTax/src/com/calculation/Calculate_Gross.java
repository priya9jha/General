package com.calculation;

public class Calculate_Gross {

    public double gross(double net_income)
    {
        double gross=0;
        if(net_income<=400000)
            return  net_income;
        else
        {
            //for initial 1,50,000, gross=1,50,000
            gross=150000;

            //subtract 1,50,000 for uncalculated net incoMe
            net_income-=150000;

            System.out.println("gross after slabA="+gross);
            //for next 1,46,250 gross=1,50,000
            gross+=150000;

            net_income-=146250;

            System.out.println("gross after slab B="+gross);
            if(net_income>=450000)
            {
                gross+=500000;

                net_income-=450000;
                System.out.println("gross after slab C="+gross);
                if(net_income==0)
                    return gross;
            }
            else
                if(net_income<450000)
            {
                gross+=net_income/0.9;
                return gross;
            }

               if(net_income>=6900000)
               {
                   gross+=9200000;
                   net_income-=6900000;
                   if(net_income==0)
                       return gross;
               }
               else
               if(net_income<6900000)
               {
                   gross+=net_income/0.75;
                   return gross;
               }

               gross+=net_income/0.7;

        }
        return gross;
    }

}
