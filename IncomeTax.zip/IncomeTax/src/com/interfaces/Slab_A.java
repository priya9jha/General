package com.interfaces;

public interface Slab_A {
   default double  slab(int sal){
       return 0;
    }

}
